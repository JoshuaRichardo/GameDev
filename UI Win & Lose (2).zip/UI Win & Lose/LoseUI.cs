using UnityEngine;
using UnityEngine.SceneManagement;

public class LoseUI : MonoBehaviour
{
    [Header("UI")]
    public GameObject losePanel;

    private bool isLose = false;

    void Start()
    {
        losePanel.SetActive(false);
    }

    public void ShowLose()
    {
        if (isLose) return;

        isLose = true;

        Time.timeScale = 0f;
        losePanel.SetActive(true);
    }

    public void Retry()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void MainMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenu");
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}