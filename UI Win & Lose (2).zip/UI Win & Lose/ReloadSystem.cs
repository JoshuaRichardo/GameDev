using UnityEngine;
using TMPro;
using System.Collections;

public class ReloadSystem : MonoBehaviour
{
    public int maxAmmo = 10;
    public int currentAmmo;

    public float reloadTime = 2f;

    public TextMeshProUGUI ammoText;
    public TextMeshProUGUI reloadText; 

    bool isReloading = false;
    void Start()
    {
        currentAmmo = maxAmmo;
        reloadText.gameObject.SetActive(false);
        UpdateUI();
    }

    void Update()
    {
        if (isReloading) return;
    }

    if (Input.GetMouseButtonDown(0)) {
        shoot();
    }

    if (Input.GetKeyDown(KeyCode.R))
    {
        StartCoroutine(Reload());
    }

    void Shoot()
    {
        if(currentAmmo <= 0)
            return;

        currentAmmo--;

        UpdateUI();
    }

    IEnumerator Reload()
    {
        isReloading = true;

        reloadText.gameObject.SetActive(true);

        yield return new WaitForSeconds(reloadTime);

        currentAmmo = maxAmmo;

        reloadText.gameObject.SetActive(false);

        UpdateUI();

        isReloading = false;
    }

    void UpdateUI()
    {
        ammoText.text = currentAmmo + " / " + maxAmmo;
    }
}