using UnityEngine;

public class CheckpointArrow : MonoBehaviour
{
    public Transform target;

    void Update()
    {
        if (target == null) return;

        Vector3 direction = target.position - transform.position;

        direction.y = 0;

        transform.rotation = Quaternion.LookRotation(direction);
    }

    // jika checkpoint pindah
    public void SetNextCheckpoint(Transform next)
    {
        target = next;
    }
}

