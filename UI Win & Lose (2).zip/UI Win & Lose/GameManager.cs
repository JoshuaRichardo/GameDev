using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {
    public static GameManager Instance;

    [Header("UI")]
    public GameObject winPanel;
    public GameObject losePanel;

    [Header("Tank")]
    public GameObject playerTanks;
    public GameObject[] enemies;

    private bool gameEnded = false;

    private void Awake() {
        Instance = this;
    }

    void Start() {
        winPanel.SetActive(false);
        losePanel.SetActive(false);

        Time.timeScale = 1f;
    }

    void Update() {
        if (gameEnded) 
        return;

        CheckWin();
    }

    void CheckWin()
    {
        int aliveEnemy = 0;

        foreach(GameObject enemy in enemies)
        {
            if(enemy != null)
            aliveEnemy++;
        }

        if(aliveEnemy == 0)
        {
            WinGame();
        }
    }

    public void WinGame()
    {
        gameEnded = true;
        winPanel.SetActive(true);
        Time.timeScale = 0f;
    }

    public void LoseGame()
    {
        gameEnded = true;
        losePanel.SetActive(true);
        Time.timeScale = 0f;
    }

    // BUTTON 

    public void Retry()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void MainMenu()
    {
        Time.timeScale= 1f;
        SceneManager.LoadScene("MainMenu");
    }

    public void NextLevel()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}