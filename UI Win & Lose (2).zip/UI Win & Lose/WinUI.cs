using UnityEngine;
using UnityEngine.SceneManagement;

public class WinUI : MonoBehaviour
{
    [Header("UI")]
    public GameObject winPanel;

    private bool isWin = false;
    void Start()
    {
        winPanel.SetActive(false);
    }

    public void ShowWin()
    {
        if (isWin) return;

        isWin = true;

        Time.timeScale = 0f;
        winPanel.SetActive(true);
    }

    public void NextLevel()
    {
        Time.timeScale = 1f;

        int currentScene = SceneManager.GetActiveScene().buildIndex;

        if(currentScene + 1 < SceneManager.sceneCountInBuildSettings) SceneManager.LoadScene(currentScene + 1);
    }

    public void Replay()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void MainMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("MainMenu");
    }
}