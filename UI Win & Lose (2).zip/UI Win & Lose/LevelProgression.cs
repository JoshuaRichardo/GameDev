using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelProgression : MonoBehaviour
{
    public int totalEnemies;

    void Update()
    {
        if(GameObject.FindGameObjectsWithTag("Enemy").Length == 0)
        {
            NextLevel();
        }
    }

    void NextLevel()
    {
        int currentScene = SceneManager.GetActiveScene().buildIndex;

        if(currentScene + 1 < SceneManager.sceneCountInBuildSettings)
        {
            SceneManager.LoadScene(currentScene + 1);
        }
        else
        {
            Debug.Log("Game Completed!");
        }
    }
}